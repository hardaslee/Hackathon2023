package hackatonSec;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.*;

public class Main {
	public static String printStrongNess(String input) {
        // Checking lower alphabet in string
        int n = input.length();
        boolean hasLower = false, hasUpper = false,
                hasDigit = false, specialChar = false;
        Set<Character> set = new HashSet<Character>(
                Arrays.asList('!', '@', '#', '$', '%', '^', '&',
                        '*', '(', ')', '-', '+', '|', '"', ' ', '\'', '\\', '.', ':', ';',
                        '>', '<' , '=', '?', '{' , '}' , '_', '[', ']', '~', '`'));
        for (char i : input.toCharArray()) {
            if (Character.isLowerCase(i))
                hasLower = true;
            if (Character.isUpperCase(i))
                hasUpper = true;
            if (Character.isDigit(i))
                hasDigit = true;
            if (set.contains(i))
                specialChar = true;
        }

        // Strength of password
        System.out.print("Password Strength:- ");

        if (hasDigit && hasLower && hasUpper && specialChar && (n >= 8)) {
            System.out.print("Strong\nPassword Saved\n");
        return "Strong";
        } else if ((hasLower || hasUpper || specialChar) && (n >= 6)) {
            System.out.print("Moderate");
            return "Moderate";
        } else
            System.out.print("Weak");
        return "Weak";
    }

    // Main Code

    public static String generatePassword(int minLength) throws Exception{
        SecureRandom random = new SecureRandom();
        StringBuilder password = new StringBuilder();

        // Define the character sets for different types of characters
        String allCharacters = "abcdefghijklmnopqrstuvwxyz";
        String characters = " ";
        String allNumbers= "0123456789";
        String allSpecial = "!@#$%^&*()-_=+[]{}|;:'\\\",.<>?\";";
        String allCharBig= "ABCDEFGHIJKLMNOPQRSTUVWXY";


        // Generate the rest of the password
        Test(random, password, allCharacters, allNumbers);
        Test(random, password, allCharBig, allSpecial);


        return shuffleString(password.toString());
        // Shuffle the characters to make it more unpredictable

    }

    private static void Test(SecureRandom random, StringBuilder password, String allCharacters, String allNumbers) {
        String characters;
        for (int i = 0; i < 2; i++) {
            characters = allCharacters;
            password.append(characters.charAt(random.nextInt(characters.length())));
        }
        for (int i = 0; i < 2; i++) {
            characters = allNumbers;
            password.append(characters.charAt(random.nextInt(characters.length())));
        }
    }

    // Function to shuffle a string
    public static String shuffleString(String input) throws Exception{
        char[] characters = input.toCharArray();
        for (int i = 0; i < characters.length; i++) {
            int randomIndex = (int) (Math.random() * characters.length);
            char temp = characters[i];
            characters[i] = characters[randomIndex];
            characters[randomIndex] = temp;
        }
        return new String(characters);
    }
    public static String hashingMdp(String password) throws Exception{
        SecureRandom random = new SecureRandom();
        byte[] salt = new byte[16];
        random.nextBytes(salt);
        MessageDigest md = MessageDigest.getInstance("SHA-512");
        md.update(salt);
        byte[] hashedPassword = md.digest(password.getBytes(StandardCharsets.UTF_8));

return hashedPassword.toString();
    }


    public static void main(String[] args) throws Exception{
        HashMap<String, String> dataSaving = new HashMap<>();
        System.out.println("..:: PASSWORD STRENGTH CHECKER ::..");
        Scanner scan = new Scanner(System.in);


        while (true) {
            System.out.println("Enter a username:");
            String userName = scan.nextLine();
            System.out.println("Enter a password:");
            String password = scan.nextLine();
            String strength = printStrongNess(password);

            if ("Strong".equals(strength)) {
                dataSaving.put(userName,hashingMdp(password));
                break; // exit the loop if the password is strong
            } else {
                System.out.println("\nPassword is " + strength + ". Would you like US to generate a stronger password for you? (Y/N)");
                String response = scan.nextLine();

                if (response.equalsIgnoreCase("Y")) {
                    // Generate and display a strong password
                    System.out.println("...:: PASSWORD IS GENERATING::...");
                    int minLength = 8;
                    String generatedPassword = generatePassword(minLength);
                    System.out.println("Generated Password: " + generatedPassword + " \nYour New Password is :" +generatedPassword);

                    dataSaving.put(userName,hashingMdp(generatedPassword));
                    break;
                } else {
                    System.out.println("Please try again.");
                }
            }
        }

    }

}

